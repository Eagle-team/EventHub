//
//  ViewController.swift
//  AudioDemo
//
//  Created by Neil Smyth on 11/9/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {

    var audioPlayer: AVAudioPlayer?
    @IBOutlet weak var volumeControl: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    let url = NSURL.fileURLWithPath(NSBundle.mainBundle().pathForResource("Moderato", ofType: "mp3")!)

    var error: NSError?

    audioPlayer = AVAudioPlayer(contentsOfURL: url, error: &error)

    if let err = error {
        println("audioPlayer error \(err.localizedDescription)")
    } else {
        audioPlayer?.delegate = self
        audioPlayer?.prepareToPlay()
    }

    }

    @IBAction func playAudio(sender: AnyObject) {
    if let player = audioPlayer {
        player.play()
    }

    }
    
    @IBAction func stopAudio(sender: AnyObject) {
    if let player = audioPlayer {
        player.stop()
    }

    }
    
    @IBAction func adjustVolume(sender: AnyObject) {
    if audioPlayer != nil {
        audioPlayer?.volume = volumeControl.value
    }

    }

    func audioPlayerDidFinishPlaying(player: AVAudioPlayer!, successfully 
            flag: Bool) {
    }

    func audioPlayerDecodeErrorDidOccur(player: AVAudioPlayer!, 
            error: NSError!) {
    }

    func audioPlayerBeginInterruption(player: AVAudioPlayer!) {
    }

    func audioPlayerEndInterruption(player: AVAudioPlayer!) {
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

