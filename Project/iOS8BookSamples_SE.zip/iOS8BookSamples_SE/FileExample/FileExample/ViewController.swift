//
//  ViewController.swift
//  FileExample
//
//  Created by Neil Smyth on 11/4/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textBox: UITextField!
    
    var fileMgr: NSFileManager = NSFileManager.defaultManager()
    var docsDir: String?
    var dataFile: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        let dirPaths = NSSearchPathForDirectoriesInDomains(
		.DocumentDirectory, .UserDomainMask, true)

        docsDir = dirPaths[0] as? String
        dataFile = 
             docsDir?.stringByAppendingPathComponent("datafile.dat")

        if fileMgr.fileExistsAtPath(dataFile!) {
            let databuffer = fileMgr.contentsAtPath(dataFile!)
            var datastring = NSString(data: databuffer!, 
				       encoding: NSUTF8StringEncoding)
            textBox.text = datastring as! String
        }

    }

    @IBAction func saveText(sender: AnyObject) {
        let databuffer = (textBox.text as 
            NSString).dataUsingEncoding(NSUTF8StringEncoding)

        fileMgr.createFileAtPath(dataFile!, contents: databuffer, 
                    attributes: nil)

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

