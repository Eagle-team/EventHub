//
//  SecondViewController.swift
//  StateApp
//
//  Created by Neil Smyth on 11/7/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    
    @IBOutlet weak var myTextView: UITextView!
    var thirdViewController: UIViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    thirdViewController = ThirdViewController(nibName: 
				"ThirdViewController", bundle: nil)

    }

    @IBAction func displayVC3(sender: AnyObject) {
    self.navigationController?.pushViewController(
			thirdViewController!, animated: true)

    }
    
    override func encodeRestorableStateWithCoder(coder: NSCoder) {
        coder.encodeObject(myTextView.text, forKey:"UnsavedText")
        super.encodeRestorableStateWithCoder(coder)
    }

    override func decodeRestorableStateWithCoder(coder: NSCoder) {
        myTextView.text = coder.decodeObjectForKey("UnsavedText") as! String
        super.decodeRestorableStateWithCoder(coder)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

