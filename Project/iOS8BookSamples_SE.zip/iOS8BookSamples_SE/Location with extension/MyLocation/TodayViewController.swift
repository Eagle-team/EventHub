//
//  TodayViewController.swift
//  MyLocation
//
//  Created by Neil Smyth on 7/30/14.
//  Copyright (c) 2014 eBookFrenzy. All rights reserved.
//

import UIKit
import NotificationCenter
import CoreLocation

class TodayViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var latitudeLabel: UILabel!
    @IBOutlet weak var longitudeLabel: UILabel!
    
    var locationManager: CLLocationManager = CLLocationManager()
    var currentLocation: CLLocation?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view from its nib.
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()

    }
 
    @IBAction func openApp(sender: AnyObject) {

        let url: NSURL = NSURL(string: "location:")!
        self.extensionContext!.openURL(url, completionHandler: nil)
    }

    override func viewWillAppear(animated: Bool)
    {
        NSLog("viewWillAppear")
        performWidgetUpdate()
    }

    func performWidgetUpdate()
    {
        
        if currentLocation != nil {
            NSLog("currentLocation is set")
            var latitudeText = String(format: "Lat: %.4f", currentLocation!.coordinate.latitude)
            var longitudeText = String(format: "Lon: %.4f", currentLocation!.coordinate.longitude)
            
            NSLog(latitudeText)
            NSLog(longitudeText)
            
            latitudeLabel.text = latitudeText
            longitudeLabel.text = longitudeText
        }
    }
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!)
    {
        currentLocation = locations[locations.count - 1] as? CLLocation
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func widgetPerformUpdateWithCompletionHandler(completionHandler: ((NCUpdateResult) -> Void)!) {
        // Perform any setup necessary in order to update the view.

        // If an error is encoutered, use NCUpdateResult.Failed
        // If there's no update required, use NCUpdateResult.NoData
        // If there's an update, use NCUpdateResult.NewData
        performWidgetUpdate()
        completionHandler(NCUpdateResult.NewData)
    }
    
}
