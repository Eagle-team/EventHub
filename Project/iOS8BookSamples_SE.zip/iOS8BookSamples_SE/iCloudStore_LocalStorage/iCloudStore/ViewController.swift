//
//  ViewController.swift
//  iCloudStore
//
//  Created by Neil Smyth on 11/4/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!

    var document: MyDocument?
    var documentURL: NSURL?

    override func viewDidLoad() {
        super.viewDidLoad()
        let dirPaths =
              NSSearchPathForDirectoriesInDomains(.DocumentDirectory,
                                .UserDomainMask, true)

        let docsDir = dirPaths[0] as! String

        let dataFile = 
                 docsDir.stringByAppendingPathComponent("savefile.txt");
        
        documentURL = NSURL(fileURLWithPath: dataFile)
        document = MyDocument(fileURL: documentURL!)
        document!.userText = ""

        let filemgr = NSFileManager.defaultManager()

        if filemgr.fileExistsAtPath(dataFile) {

            document?.openWithCompletionHandler({(success: Bool) -> Void in
                if success {
                    println("File open OK")
                    self.textView.text = self.document?.userText
                } else {
                    println("Failed to open file")               }
            })
        } else {
            document?.saveToURL(documentURL!, forSaveOperation: 
            .ForCreating,
                     completionHandler: {(success: Bool) -> Void in
                if success {
                    println("File created OK")
                } else {
                    println("Failed to create file ")
                }
            })
        }

    }

    @IBAction func saveDocument(sender: AnyObject) {
        document!.userText = textView.text

        document?.saveToURL(documentURL!, 
           forSaveOperation: .ForOverwriting, 
               completionHandler: {(success: Bool) -> Void in
            if success {
                println("File overwrite OK")
            } else {
                println("File overwrite failed")
            }
    })

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

