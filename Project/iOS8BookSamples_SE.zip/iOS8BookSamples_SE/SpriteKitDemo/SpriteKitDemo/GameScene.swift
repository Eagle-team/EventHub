//
//  GameScene.swift
//  SpriteKitDemo
//
//  Created by Neil Smyth on 11/6/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        /* Called when a touch begins */
        let welcomeNode = childNodeWithName("welcomeNode")

        if (welcomeNode != nil) {
            let fadeAway = SKAction.fadeOutWithDuration(1.0)

            welcomeNode?.runAction(fadeAway, completion: {
                let doors = SKTransition.doorwayWithDuration(1.0)
                let archeryScene = ArcheryScene(fileNamed: "ArcheryScene")
                self.view?.presentScene(archeryScene, transition: doors)
            })
        }
        
    }
   
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}
