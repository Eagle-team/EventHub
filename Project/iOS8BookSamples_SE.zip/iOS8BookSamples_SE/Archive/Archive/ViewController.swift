//
//  ViewController.swift
//  Archive
//
//  Created by Neil Smyth on 11/5/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var phone: UITextField!

    var dataFilePath: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let filemgr = NSFileManager.defaultManager()
        let dirPaths = 
            NSSearchPathForDirectoriesInDomains(.DocumentDirectory, 
                        .UserDomainMask, true)

        let docsDir = dirPaths[0] as! String
        dataFilePath = 
            docsDir.stringByAppendingPathComponent("data.archive")

        if filemgr.fileExistsAtPath(dataFilePath!) {
           let dataArray = 
            NSKeyedUnarchiver.unarchiveObjectWithFile(dataFilePath!) 
                            as! [String]
            name.text = dataArray[0]
            address.text = dataArray[1]
            phone.text = dataArray[2]
        }

    }

    @IBAction func saveData(sender: AnyObject) {
        var contactArray = [name.text, address.text, phone.text]
        NSKeyedArchiver.archiveRootObject(contactArray, 
                        toFile: dataFilePath!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

